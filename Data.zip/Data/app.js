﻿import React, { useState, useEffect } from 'react';
import { Moon, Sun, Plus, Trash2, Edit2, Check, X } from 'lucide-react';

const StudyTracker = () => {
  const [theme, setTheme] = useState('light');
  const [sections, setSections] = useState({
    excel: [],
    sql: [],
    python: [],
    visualization: [],
    projects: []
  });
  const [editingId, setEditingId] = useState(null);
  const [editValues, setEditValues] = useState({ topic: '', note: '', challenge: '' });

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'light';
    const savedSections = localStorage.getItem('studySections');
    setTheme(savedTheme);
    if (savedSections) {
      setSections(JSON.parse(savedSections));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    localStorage.setItem('studySections', JSON.stringify(sections));
  }, [theme, sections]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const addEntry = (section) => {
    const newEntry = {
      id: Date.now(),
      topic: '',
      note: '',
      challenge: '',
      isNew: true
    };
    setSections(prev => ({
      ...prev,
      [section]: [...prev[section], newEntry]
    }));
    setEditingId(newEntry.id);
    setEditValues({ topic: '', note: '', challenge: '' });
  };

  const deleteEntry = (section, id) => {
    setSections(prev => ({
      ...prev,
      [section]: prev[section].filter(entry => entry.id !== id)
    }));
  };

  const startEdit = (entry) => {
    setEditingId(entry.id);
    setEditValues({ topic: entry.topic, note: entry.note, challenge: entry.challenge });
  };

  const saveEdit = (section, id) => {
    setSections(prev => ({
      ...prev,
      [section]: prev[section].map(entry =>
        entry.id === id ? { ...entry, ...editValues, isNew: false } : entry
      )
    }));
    setEditingId(null);
  };

  const cancelEdit = (section, id) => {
    setSections(prev => ({
      ...prev,
      [section]: prev[section].filter(entry => entry.id !== id || !entry.isNew)
    }));
    setEditingId(null);
  };

  const sectionColors = {
    excel: 'border-l-4 border-l-emerald-600',
    sql: 'border-l-4 border-l-blue-600',
    python: 'border-l-4 border-l-amber-600',
    visualization: 'border-l-4 border-l-purple-600',
    projects: 'border-l-4 border-l-red-600'
  };

  const sectionNames = {
    excel: 'EXCEL',
    sql: 'SQL',
    python: 'PYTHON',
    visualization: 'DATA VISUALIZATION',
    projects: 'PROJECTS'
  };

  const bgClass = theme === 'light' ? 'bg-gray-50' : 'bg-gray-900';
  const cardBg = theme === 'light' ? 'bg-white' : 'bg-gray-800';
  const textPrimary = theme === 'light' ? 'text-gray-900' : 'text-gray-100';
  const textSecondary = theme === 'light' ? 'text-gray-600' : 'text-gray-400';
  const border = theme === 'light' ? 'border-gray-200' : 'border-gray-700';
  const inputBg = theme === 'light' ? 'bg-gray-50' : 'bg-gray-700';

  return (
    <div className={`min-h-screen ${bgClass} ${textPrimary} transition-colors duration-200`}>
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl tracking-wide" style={{ fontWeight: 450 }}>Data</h1>
          <button
            onClick={toggleTheme}
            className={`p-2 rounded-lg ${cardBg} ${border} border transition-all hover:scale-105`}
          >
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>
        </div>

        {Object.entries(sectionNames).map(([key, title]) => (
          <div key={key} className={`${cardBg} rounded-lg p-6 mb-6 shadow-sm border ${border} ${sectionColors[key]}`}>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold tracking-wide">{title}</h2>
              <button
                onClick={() => addEntry(key)}
                className={`flex items-center gap-2 px-4 py-2 border ${border} rounded-lg transition-colors ${theme === 'light' ? 'hover:bg-gray-100' : 'hover:bg-gray-700'}`}
              >
                <Plus size={18} />
                Add Entry
              </button>
            </div>

            <div className="space-y-3">
              {sections[key].length === 0 ? (
                <p className={`${textSecondary} text-center py-8`}>No entries yet. Click "Add Entry" to start tracking.</p>
              ) : (
                sections[key].map(entry => (
                  <div key={entry.id} className={`p-4 rounded-lg border ${border} ${inputBg}`}>
                    {editingId === entry.id ? (
                      <div className="space-y-3">
                        <input
                          type="text"
                          placeholder="Topic"
                          value={editValues.topic}
                          onChange={(e) => setEditValues(prev => ({ ...prev, topic: e.target.value }))}
                          className={`w-full px-3 py-2 rounded border ${border} ${inputBg} ${textPrimary} focus:outline-none focus:ring-2 focus:ring-blue-500`}
                        />
                        <textarea
                          placeholder="Note"
                          value={editValues.note}
                          onChange={(e) => setEditValues(prev => ({ ...prev, note: e.target.value }))}
                          className={`w-full px-3 py-2 rounded border ${border} ${inputBg} ${textPrimary} focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none`}
                          rows={2}
                        />
                        <textarea
                          placeholder="Challenge"
                          value={editValues.challenge}
                          onChange={(e) => setEditValues(prev => ({ ...prev, challenge: e.target.value }))}
                          className={`w-full px-3 py-2 rounded border ${border} ${inputBg} ${textPrimary} focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none`}
                          rows={2}
                        />
                        <div className="flex gap-2 justify-end">
                          <button
                            onClick={() => saveEdit(key, entry.id)}
                            className="p-2 bg-green-600 text-white rounded hover:bg-green-700 transition-colors"
                          >
                            <Check size={18} />
                          </button>
                          <button
                            onClick={() => cancelEdit(key, entry.id)}
                            className="p-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
                          >
                            <X size={18} />
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-semibold text-lg">{entry.topic || 'Untitled'}</h3>
                          <div className="flex gap-2">
                            <button
                              onClick={() => startEdit(entry)}
                              className={`p-1.5 rounded hover:bg-opacity-80 transition-colors ${theme === 'light' ? 'hover:bg-gray-200' : 'hover:bg-gray-600'}`}
                            >
                              <Edit2 size={16} />
                            </button>
                            <button
                              onClick={() => deleteEntry(key, entry.id)}
                              className={`p-1.5 rounded hover:bg-opacity-80 transition-colors ${theme === 'light' ? 'hover:bg-gray-200' : 'hover:bg-gray-600'}`}
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                        {entry.note && (
                          <p className={`${textSecondary} mb-2 text-sm`}>
                            <span className="font-medium">Note:</span> {entry.note}
                          </p>
                        )}
                        {entry.challenge && (
                          <p className={`${textSecondary} text-sm`}>
                            <span className="font-medium">Challenge:</span> {entry.challenge}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StudyTracker;
